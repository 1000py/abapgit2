-- Mass Edit


1. Manifest.json

},
              "controlConfiguration": {
                "@com.sap.vocabularies.UI.v1.LineItem": {
                  "tableSettings": {
                    "type": "ResponsiveTable",
                    "enableMassEdit": {},
                    "enableExport": true,
                    "personalization": {
                      "column": true,
                      "sort": true,
                      "filter": true,
                      "group": true
                    }
                  }
                }
              }



2. List Controller

const oMassEditBtn = this.getView().byId('ynewversion::ZC_INTEGRATED_PWJList--fe::table::ZC_INTEGRATED_PWJ::LineItem::StandardAction::MassEdit');
				oMassEditBtn.setText("Mass Edit");