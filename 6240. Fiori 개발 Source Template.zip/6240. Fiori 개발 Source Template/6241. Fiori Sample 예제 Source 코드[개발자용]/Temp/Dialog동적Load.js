/**
 * 20250909 - 박원종 ( park.wj@biztechi.com ) 최초 생성
 * 생성한 Dialog Load
 */

CustomHTMLColumn.fragment.xml
<core:FragmentDefinition xmlns:core="sap.ui.core" xmlns="sap.m">
    <Dialog id="customHtmlDialog" title="구매관리 상세 HTML" draggable="true" resizable="true">
        <content>
            <ScrollContainer vertical="true" horizontal="false" height="400px">
                <core:HTML id="customHtmlContent" content="{/htmlContent}" />
            </ScrollContainer>
        </content>
        <endButton>
            <Button id="btnCloseCustomHtmlDialog" text="닫기" press="onCloseCustomHtmlDialog"/>
        </endButton>
    </Dialog>
</core:FragmentDefinition>


onBtnPressTest02: function(oEvent){
            var oView = this.getView();
            var sHtmlContent = "<div style='padding:16px; font-family:Arial;'><h2 style='color:#1976d2;'>구매관리 상세</h2><table style='width:100%; border-collapse:collapse;'><tr style='background:#f5f5f5;'><th style='padding:8px; border:1px solid #ccc;'>항목</th><th style='padding:8px; border:1px solid #ccc;'>값</th></tr><tr><td style='padding:8px; border:1px solid #ccc;'>주문번호</td><td style='padding:8px; border:1px solid #ccc;'>81901</td></tr><tr><td style='padding:8px; border:1px solid #ccc;'>주문자</td><td style='padding:8px; border:1px solid #ccc;'>홍길동</td></tr><tr><td style='padding:8px; border:1px solid #ccc;'>상품명</td><td style='padding:8px; border:1px solid #ccc;'>테스트상품</td></tr><tr><td style='padding:8px; border:1px solid #ccc;'>수량</td><td style='padding:8px; border:1px solid #ccc;'>10</td></tr><tr><td style='padding:8px; border:1px solid #ccc;'>금액</td><td style='padding:8px; border:1px solid #ccc;'>100,000원</td></tr></table><div style='margin-top:24px; color:#666;'><b>비고:</b> 테스트 주문입니다.</div></div>";
            var oDialogModel = new JSONModel({
                htmlContent: sHtmlContent
            });
            if (!this._pCustomHtmlDialog) {
                this._pCustomHtmlDialog = sap.ui.core.Fragment.load({
                    name: "zbiztechi0060.ext.fragment.CustomHTMLColumn",
                    controller: this
                }).then(function(oDialog){
                    oView.addDependent(oDialog);
                    oDialog.setModel(oDialogModel);
                    oDialog.open();
                    return oDialog;
                });
            } else {
                this._pCustomHtmlDialog.then(function(oDialog){
                    oDialog.setModel(oDialogModel);
                    oDialog.open();
                });
            }
        },