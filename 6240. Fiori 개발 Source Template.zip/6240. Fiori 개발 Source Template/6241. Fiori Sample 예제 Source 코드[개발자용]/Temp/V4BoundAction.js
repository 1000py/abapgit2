/**
 * 20250903 - 박원종 ( park.wj@biztechi.com ) 최초 작성
 * Action Parameter 데이터 가공 시 호출 하는 방법 예시입니다.
 * RAP에서 생성한 Action을 metadata에서 확인하여 필수 파라미터들을 기입하고 송신합니다.
 * function testAction를 참조하시면 됩니다.
 * 
 */

sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/plugins/CopyProvider",
    "sap/m/plugins/PasteProvider",
    "sap/ui/model/odata/type/DateTimeWithTimezone",
	"sap/ui/model/odata/v4/ODataUtils"
], function(
    MessageToast,
    CopyProvider,
    PasteProvider,
    DateTimeWithTimezon,
    ODataUtils) {
    'use strict';

    return {
        onCopyParameters: function(oEvent) {
            MessageToast.show("Custom handler invoked.");
            const oView = this._view;
            const oContext = oView.getBindingContext();
            let oData = oContext.getObject();
            let aFields = [
                "OrderUuid", "OrderId", "OrderedItem", "Price", "TotalPrice", "OrderQuantity", "DeliveryDate", "OverallStatus", "Notes"
            ];
            var aLines = aFields.map(function(field) {
                return field + ": " + (oData[field] !== undefined ? oData[field] : "");
            });            
            var sText = aLines.join("\n");
            // 클립보드 복사
            // Clipboard.copy(sText);
            navigator.clipboard.writeText(sText)
            .then(() => {
                console.log("클립보드에 복사되었습니다!");
            })
            .catch(err => {
                console.error("클립보드 복사 실패:", err);
            });
            MessageToast.show("General Information이 클립보드에 복사되었습니다.");
        },
        onPasteParameters: function(oEvent) {
            var that = this;
            if (navigator.clipboard && navigator.clipboard.readText) {
                navigator.clipboard.readText().then(function(text) {
                    var oView = that._view;
                    var oContext = oView.getBindingContext();
                    var oData = oContext.getObject();
                    var aLines = text.split(/\r?\n/);
                    aLines.forEach(function(line) {
                        var parts = line.split(": ");
                        if (parts.length === 2) {
                            var key = parts[0];
                            var value = parts[1];
                            if (oData.hasOwnProperty(key)) {
                                oData[key] = value;
                                // 실제 input id 패턴에 맞게 id 생성 (Field-edit, Field-edit-inner 모두 시도)
                                var sBaseId = 'fe::FormContainer::GeneralInfo::FormElement::DataField::' + key + '::Field-edit';
                                var oInput = oView.byId(sBaseId);
                                var oInputInner = oView.byId(sBaseId + '-inner');
                                // price/totalprice 필드는 Field-edit, Fie  `ld-edit-inner 모두 시도
                                if (key === "Price" || key === "TotalPrice") {
                                    var fVal = parseFloat(value);
                                    if (!isNaN(fVal)) {
                                        value = fVal.toFixed(2);
                                    }
                                    // Field-edit: setValue([value, ...])
                                    if (oInput && typeof oInput.setValue === "function") {
                                        try {
                                            oInput.setValue([value, "", {}]);
                                        } catch (e) {
                                            MessageToast.show("입력 오류: " + e);
                                        }
                                    }
                                    // Field-edit-inner: setValue(문자열)
                                    if (oInputInner && typeof oInputInner.setValue === "function") {
                                        try {
                                            oInputInner.setValue(value);
                                        } catch (e) {
                                            MessageToast.
                                            show("입력 오류: " + e);
                                        }
                                    }
                                } else {
                                    // 일반 필드
                                    if (oInput && typeof oInput.setValue === "function") {
                                        try {
                                            oInput.setValue(value);
                                        } catch (e) {
                                            MessageToast.show("입력 오류: " + e);
                                        }
                                    }
                                }
                            }
                        }
                    });
                    MessageToast.show("클립보드 값이 입력값에 반영되었습니다.");
                }).catch(function(err) {
                    MessageToast.show("클립보드 읽기 실패: " + err);
                });
            } else {
                MessageToast.show("브라우저가 클립보드 읽기를 지원하지 않습니다.");
            }
        },

        onRealCopyAction : function(oEvent){
            var oView = this._view;
            var oModel = oView.getModel();
            var oContext = oView.getBindingContext();
            var sPath = oContext.getPath();
            // 임의의 데이터, 실제 RAP 액션 파라미터에 맞게 수정
            var oParameters = {
                OrderId         : "12345678",
                OrderedItem     : "테스트아이템",
                Currency        : "KRW",
                Price           : 1000.00,
                TotalPrice      : 2000.00,
                OrderQuantity   : "10",
                DeliveryDate    : "20250814",
                OverallStatus   : "신규",
                Notes           : "CopyData 테스트"
            };

    
            let oActionContext = oModel.bindContext("com.sap.gateway.srvd.zui_ashopcart_pwj_o4.v0001.CopyData(...)", oEvent, {
                "$$groupId" : "$direct"
            });

            oAction.getParameterContext().setProperty('CLIENT'                  , "080");
            oAction.getParameterContext().setProperty('ORDER_UUID'              , "fa163eae-3e59-1fe0-9efd-00f5ea4ab87b");
            oAction.getParameterContext().setProperty('ORDER_ID'                , "0819");
            oAction.getParameterContext().setProperty('ORDERED_ITEM'            , "0819");
            oAction.getParameterContext().setProperty('CURRENCY'                , "KRW");
            oAction.getParameterContext().setProperty('PRICE'                   , "1000.00");
            oAction.getParameterContext().setProperty('TOTAL_PRICE'             , "2000.00");
            oAction.getParameterContext().setProperty('ORDER_QUANTITY'          , "10");
            oAction.getParameterContext().setProperty('DELIVERY_DATE'           , '2025-01-01');
            oAction.getParameterContext().setProperty('OVERALL_STATUS'          , "신규");
            oAction.getParameterContext().setProperty('NOTES'                   , "CopyData 테스트");
            oAction.getParameterContext().setProperty('CREATED_BY'              , "CC0000000015");
            oAction.getParameterContext().setProperty('CREATED_AT'              , "2022-12-31T08:15:00Z");
            oAction.getParameterContext().setProperty('LAST_CHANGED_BY'         , "CC0000000015");
            oAction.getParameterContext().setProperty('LAST_CHANGED_AT'         , "2022-12-31T08:15:00Z");
            oAction.getParameterContext().setProperty('LOCAL_LAST_CHANGED_AT'   , "2022-12-31T08:15:00Z");
            oAction.getParameterContext().setProperty('PURCHASE_REQUISITION'    , "");
            oAction.getParameterContext().setProperty('PR_CREATION_DATE'        , '2025-01-01');

            oActionContext.execute()
            .then(function(result){
                console.log('요청 완료되었습니다.');
            }.bind(this))
            .catch(function(e){
                console.log('관리자에게 문의 부탁드립니다.');
            }.bind(this));
            
            
        },

        testAction: function(oEvent){
            var oView = this._view;
            var oModel = oView.getModel();
            var oAction = oModel.bindContext("com.sap.gateway.srvd.zui_ashopcart_pwj_o4.v0001.CopyData(...)", oEvent, {
                $$groupId: "$direct"
            });

            oAction.getParameterContext().setProperty('CLIENT'                  , "080");
            oAction.getParameterContext().setProperty('ORDER_UUID'              , "fa163eae-3e59-1fe0-9efd-00f5ea4ab87b");
            oAction.getParameterContext().setProperty('ORDER_ID'                , "0819");
            oAction.getParameterContext().setProperty('ORDERED_ITEM'            , "0819");
            oAction.getParameterContext().setProperty('CURRENCY'                , "KRW");
            oAction.getParameterContext().setProperty('PRICE'                   , "1000.00");
            oAction.getParameterContext().setProperty('TOTAL_PRICE'             , "2000.00");
            oAction.getParameterContext().setProperty('ORDER_QUANTITY'          , "10");
            oAction.getParameterContext().setProperty('DELIVERY_DATE'           , '2025-01-01');
            oAction.getParameterContext().setProperty('OVERALL_STATUS'          , "신규");
            oAction.getParameterContext().setProperty('NOTES'                   , "CopyData 테스트");
            oAction.getParameterContext().setProperty('CREATED_BY'              , "CC0000000015");
            oAction.getParameterContext().setProperty('CREATED_AT'              , "2022-12-31T08:15:00Z");
            oAction.getParameterContext().setProperty('LAST_CHANGED_BY'         , "CC0000000015");
            oAction.getParameterContext().setProperty('LAST_CHANGED_AT'         , "2022-12-31T08:15:00Z");
            oAction.getParameterContext().setProperty('LOCAL_LAST_CHANGED_AT'   , "2022-12-31T08:15:00Z");
            oAction.getParameterContext().setProperty('PURCHASE_REQUISITION'    , "");
            oAction.getParameterContext().setProperty('PR_CREATION_DATE'        , '2025-01-01');

            oAction.invoke().then(
                function(oResult) {
                    // MessageToast.show("CopyData RAP 액션 성공: " + JSON.stringify(oResult.getObject()));
                    let realResult = oAction.getBoundContext().getObject();
                    console.log('123');
                },
                function(oError) {
                    MessageToast.show("CopyData RAP 액션 실패: " + oError.message);
                }
            );


        },
        onExcelDownload: function(oEvent) {
            // TODO: 실제 엑셀 다운로드 로직 구현
            sap.m.MessageToast.show("Excel Download 버튼 클릭됨");
        }
    };
});
