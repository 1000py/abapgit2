sap.ui.define(['sap/ui/core/mvc/ControllerExtension'], function (ControllerExtension) {
	'use strict';

	return ControllerExtension.extend('com.biztechi.zbiztechi0070.ext.controller.RenderObjectController', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf com.biztechi.zbiztechi0070.ext.controller.RenderObjectController
             */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
			},

			onPageReady: function(oEvent) {
				const oView = this.getView();
				const oCtx  = oView.getBindingContext();
				const bEditable = oView.getModel("ui")?.getProperty("/isEditable");

				if (!bEditable && oCtx) {
					const sPath = oCtx.getPath();
					if (sPath.includes("IsActiveEntity=true")) {
						this.base.editFlow.editDocument(oCtx);	
					} else {
						console.warn("Context is not active entity:", sPath);
					}
				}
			}
		}
	});
});
