/**
 * Fiori Elements - List Page를 Extends한 Controller에서 진행합니다.
 * ListPageExt.controller.js
 * Share 버튼 옆, Share 버튼 옆(아이콘 추가) 2가지 버전 
 */


sap.ui.define(['sap/ui/core/mvc/ControllerExtension'], function (ControllerExtension) {
	'use strict';

	return ControllerExtension.extend('zsample0020.ext.controller.ListPageExt', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf zsample0020.ext.controller.ListPageExt
             */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
				this.getView().byId('zsample0020::ZC_INTEGRATED_PWJList--fe::FilterBar::ZC_INTEGRATED_PWJ-btnSearch').setText('search');
			},

			/*
				-- Share 버튼 옆(아이콘 추가) -- 
			*/	
			onAfterRendering: function(){
				var VM_ID = "fe::PageVariantManagement-vm";
				var vm = this.base.byId(VM_ID);
				if (vm) vm.addStyleClass("vm-standard-custom");   // 커스텀 클래스 부여
				if (!vm) return;
 
				// 1) DynamicPageTitle 찾기
				var dpt = vm.getParent();
				while (dpt && !dpt.isA("sap.f.DynamicPageTitle")) {
					dpt = dpt.getParent();
				}
				if (!dpt) return;
 
				// 2) VM을 오른쪽 actions 영역으로 이동
				dpt.removeAction(vm);
				dpt.addAction(vm);
 
				// 3) 원래 VM이 있던 래퍼(HorizontalLayout 등)를 완전히 제거
				var oldParent = vm.getParent();
				while (oldParent && !oldParent.isA("sap.f.DynamicPageTitle")) {
					var next = oldParent.getParent();
 
					// HorizontalLayout 이나 Toolbar 같은 래퍼면 제거
					if (oldParent.isA("sap.ui.layout.HorizontalLayout") ||
						oldParent.isA("sap.m.OverflowToolbar") ||
						oldParent.isA("sap.m.Toolbar")) {
						try {
							oldParent.destroy();   // UI5 컨트롤 레벨 제거
						} catch (e) {}
						if (oldParent.getDomRef()) {
							jQuery(oldParent.getDomRef()).remove(); 
						}
						break;
					}
					oldParent = next;
				}
 
				// 4) VM 오른쪽에 아이콘 추가
				sap.ui.require(["sap/ui/core/Icon"], function (Icon) {
					var icon = new Icon({
						src: "sap-icon://course-program",
						decorative: true
					}).addStyleClass("vm-left-blue");  
 
					var idx = dpt.indexOfAction(vm);
					dpt.insertAction(icon, idx);
				});
 
				// 5) 렌더링 갱신
				vm.invalidate();
				sap.ui.getCore().applyChanges();
			},

			/*
				-- Share 버튼 옆 -- 
			*/				
			// onAfterRendering: function () {
			// 	// 여기만 화면에 맞게 수정
			// 	var VM_ID = "fe::PageVariantManagement-vm";   // 페이지 VM의 ID
			// 	var FB_ID   = "fe::FilterBar::YCCMC01_SO_C";              // FilterBar

			// 	// vm css적용
			// 	var vm = this.base.byId(VM_ID);
			// 	if (vm) vm.addStyleClass("vm-standard-custom");   // ← 커스텀 클래스 부여
			// 	if (!vm) return;

			// 	// DynamicPageTitle 부모 찾기
			// 	var dpt = vm.getParent();
			// 	while (dpt && !(dpt.isA && dpt.isA("sap.f.DynamicPageTitle"))) {
			// 		dpt = dpt.getParent && dpt.getParent();
			// 	}
			// 	if (!dpt) return;

			// 	// 1) "원본" VM을 오른쪽(actions)으로 이동(맨 끝)
			// 	dpt.removeAction?.(vm);
			// 	dpt.addAction?.(vm);

			// 	// 2) 왼쪽 영역(heading/snapped/expanded)에 남은 VM 대표(라벨/별표/트리거) 제거
			// 	var nuke = a =>
			// 		a?.findAggregatedObjects?.(true, c => (c.getId?.() || "").includes("PageVariantManagement-vm"))
			// 		?.forEach(c => c.destroy());
			// 	nuke(dpt.getHeading?.());
			// 	nuke(dpt.getSnappedHeading?.());
			// 	nuke(dpt.getExpandedHeading?.());

			// 	// 3) 렌더링 갱신(팝오버 앵커가 오른쪽으로 고정됨)
			// 	vm.invalidate();
			// 	sap.ui.getCore().applyChanges();
			// }

		}
	});
});
